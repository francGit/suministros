import { useLocation } from "react-router-dom"
import MyRoutes from "./router/MyRoutes" 

 function App() { 
 
  return (
    <>
      <MyRoutes />
    </>
  )
}

export default App
