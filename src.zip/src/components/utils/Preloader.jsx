import React from 'react'
export const Preloader = () => {
  return (
    <div className='preloaderBox'>
        <div><img src="../../assets/preloaderIcon.gif" alt="" /></div>
    </div>
  )
}
