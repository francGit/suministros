import React from 'react'

export const ListadoProductos = () => {
  return (
    <div>ListadoProductos</div>
  )
}
